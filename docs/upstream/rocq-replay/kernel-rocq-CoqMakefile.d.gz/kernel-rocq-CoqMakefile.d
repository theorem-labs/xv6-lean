KernelInstrs.vo KernelInstrs.glob KernelInstrs.v.beautified KernelInstrs.required_vo: KernelInstrs.v /tmp/xv6-lean-research/opam-paper-audit/paper-9.0.1/lib/rocq-runtime/rocqworker
KernelInstrs.vos KernelInstrs.vok KernelInstrs.required_vos: KernelInstrs.v /tmp/xv6-lean-research/opam-paper-audit/paper-9.0.1/lib/rocq-runtime/rocqworker
KernelData.vo KernelData.glob KernelData.v.beautified KernelData.required_vo: KernelData.v /tmp/xv6-lean-research/opam-paper-audit/paper-9.0.1/lib/rocq-runtime/rocqworker
KernelData.vos KernelData.vok KernelData.required_vos: KernelData.v /tmp/xv6-lean-research/opam-paper-audit/paper-9.0.1/lib/rocq-runtime/rocqworker
KernelSyms.vo KernelSyms.glob KernelSyms.v.beautified KernelSyms.required_vo: KernelSyms.v /tmp/xv6-lean-research/opam-paper-audit/paper-9.0.1/lib/rocq-runtime/rocqworker
KernelSyms.vos KernelSyms.vok KernelSyms.required_vos: KernelSyms.v /tmp/xv6-lean-research/opam-paper-audit/paper-9.0.1/lib/rocq-runtime/rocqworker
KernelElfRaw.vo KernelElfRaw.glob KernelElfRaw.v.beautified KernelElfRaw.required_vo: KernelElfRaw.v /tmp/xv6-lean-research/opam-paper-audit/paper-9.0.1/lib/rocq-runtime/rocqworker
KernelElfRaw.vos KernelElfRaw.vok KernelElfRaw.required_vos: KernelElfRaw.v /tmp/xv6-lean-research/opam-paper-audit/paper-9.0.1/lib/rocq-runtime/rocqworker
FsImgRaw.vo FsImgRaw.glob FsImgRaw.v.beautified FsImgRaw.required_vo: FsImgRaw.v /tmp/xv6-lean-research/opam-paper-audit/paper-9.0.1/lib/rocq-runtime/rocqworker
FsImgRaw.vos FsImgRaw.vok FsImgRaw.required_vos: FsImgRaw.v /tmp/xv6-lean-research/opam-paper-audit/paper-9.0.1/lib/rocq-runtime/rocqworker
